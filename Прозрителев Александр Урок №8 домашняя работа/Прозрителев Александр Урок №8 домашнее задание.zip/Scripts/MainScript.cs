﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.Audio;

public class MainScript : MonoBehaviour
{
    #region PrivateData
    
    public enum GameStatus
    {
        Pause,
        Win,
        Loose
    }

    #endregion


    #region Fields

    public float _victoryDelay = 2.0f;
    [SerializeField] private GameObject _menu;    
    [SerializeField] private Button _buttonResume;
    [SerializeField] private Text _menuHeader;
    [SerializeField] private Color _pauseColor;
    [SerializeField] private Color _winColor;
    [SerializeField] private Color _looseColor;    

    [SerializeField] private AudioMixer _audioMixer;

    [SerializeField] private Slider _masterVolume;
    [SerializeField] private Slider _musicVolume;
    [SerializeField] private Slider _weaponVolume;

    [SerializeField] private float _delay = 4.0f;

    private GameStatus gameStatus = GameStatus.Pause;
    private float delay;
    private string killScore;
    private int mainMenuScene = 0;
    private int loadScreenScene = 1;
    private int firstLevelScene = 2;

    #endregion


    #region UnityMethods
    
    private void Start()
    {
        MyAudioController.LoadVolumeSettings(_audioMixer);

        SetVolumeSliders();                

        delay = _delay;
        Global.CurrentScene = SceneManager.GetActiveScene().buildIndex;
        Global.NextScene = NextScene();
        if (Global.CurrentScene >= firstLevelScene)
        {
            Global.Pause = false;
            ControlMenu();
        }

        
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Global.Pause = !Global.Pause;
            ControlMenu();

        }
    }

    #endregion


    #region Methods 

    private void MenuStatus()
    {
        switch (gameStatus)
        {
            case GameStatus.Pause:
                _menuHeader.text = "Пауза";
                _menuHeader.color = _pauseColor;
                _buttonResume.interactable = true;                
                break;
            case GameStatus.Loose:
                _menuHeader.text = "Облом ... ";
                _menuHeader.color = _looseColor;
                _buttonResume.interactable = false;                
                break;
            case GameStatus.Win:
                print($"Scene {Global.CurrentScene} SceneCount {SceneManager.sceneCountInBuildSettings}");                
                
                if ((Global.CurrentScene + 1) == SceneManager.sceneCountInBuildSettings)
                {
                    _buttonResume.interactable = false;
                    _menuHeader.text = "Игра окончена";                    
                }
                else
                {
                    _buttonResume.interactable = true;
                    _menuHeader.text = "Чотенько :)";
                }
                _menuHeader.color = _winColor;

                break;
            default:
                _buttonResume.interactable = true;
                _menuHeader.text = "багуля :(";
                _menuHeader.color = _looseColor;
                break;
        }
    }

    private void ControlMenu()
    {
        _menu.SetActive(Global.Pause);
        if (Global.Pause)
        {
            MenuStatus();
            Time.timeScale = 0;            
        }
        else
        {
            Time.timeScale = 1;
        }
    }

    public int NextScene()
    {
        if (((Global.CurrentScene + 1) == SceneManager.sceneCountInBuildSettings))
        {
            return mainMenuScene;
        }
        else if (Global.CurrentScene == mainMenuScene)
        {
            return firstLevelScene;
        }
        else
        {
            return (Global.CurrentScene + 1);
        }

    }

    public void NewLevel()
    {
        Global.Pause = false;
        Time.timeScale = 1;
        Global.NextScene = NextScene();
       LoadNewScene(loadScreenScene);
    }

    public void MainMenu()
    {
       LoadNewScene(mainMenuScene);
    }

    public void Resume()
    {       
        switch (gameStatus)
        {
            case GameStatus.Pause:
                Global.Pause = false;
                ControlMenu();
                break;
            case GameStatus.Loose:
                MainMenu();
                break;
            case GameStatus.Win:
                NewLevel();
                break;
            default:
                MainMenu();
                break;
        }
    }

    public void ExitGame()
    {
        print("Exit game");
        Application.Quit();
    }

    public void RestartLevel()
    {
        Global.Pause = false;
        gameStatus = GameStatus.Pause;
        ControlMenu();
       LoadNewScene(Global.CurrentScene);
    }

    private string KillScore()
    {
        return "kills: " + Global.Kills;
    }

    public void Loose()
    {
        print("Слыыы...ты лах");
        gameStatus = GameStatus.Loose;
        Global.Pause = true;
        ControlMenu();
    }

    public void Victory()
    {
        Invoke("MakeVictory", _victoryDelay);
    }

    public void MakeVictory()
    {
        print("Чотенько :) ");
        gameStatus = GameStatus.Win;
        Global.Pause = true;
        ControlMenu();
    }

    //private void SetVolumeSlider(Slider volumeS, string group)
    //{
    //    _audioMixer.GetFloat(group, out float volume);
    //    volumeS.value = volume;
    //}

    private void SetVolumeSlider(Slider volumeS, float volume)
    {
        volumeS.value = volume;
        print($"{volumeS.name} = {volume}");
    }

    private void SetVolumeSliders()
    {
        //SetVolumeSlider(_masterVolume, "MasterVolume");
        //SetVolumeSlider(_musicVolume, "MusicVolume");
        //SetVolumeSlider(_weaponVolume, "WeaponVolume");
        SetVolumeSlider(_masterVolume, MyAudioController.MasterVolume);
        SetVolumeSlider(_musicVolume, MyAudioController.MusicVolume);
        SetVolumeSlider(_weaponVolume, MyAudioController.WeaponVolume);
        ChangeVollume();
    }

    public void ChangeVollume()
    {
        _audioMixer.SetFloat("MusicVolume", _musicVolume.value);
        _audioMixer.SetFloat("WeaponVolume", _weaponVolume.value);
        _audioMixer.SetFloat("MasterVolume", _masterVolume.value);        
    }

    private void LoadNewScene(int sceneNumber)
    {
        MyAudioController.SaveVolumeSettings(_audioMixer);
        SceneManager.LoadScene(sceneNumber);
    }

    #endregion
}
