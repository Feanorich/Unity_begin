﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

public class BackGroundMusic : MonoBehaviour
{
    #region Fields

    [SerializeField] private AudioMixer _audioMixer;

    #endregion


    #region UnityMethods  

    private void Awake()
    {
        GameObject[] objs = GameObject.FindGameObjectsWithTag("Music");

        if (objs.Length > 1)
        {
            Destroy(this.gameObject);
        }

        DontDestroyOnLoad(this.gameObject);
    }

    private void Start()
    {
        MyAudioController.SaveVolumeSettings(_audioMixer);
    }

    #endregion

}
