﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

/// <summary>
/// Содержит параметры аудио
/// </summary>
public static class MyAudioController
{
    #region Fields

    public static float MasterVolume;
    public static float MusicVolume;
    public static float WeaponVolume;

    #endregion


    #region Methods 

    public static void SaveVolume(AudioMixer mixer, string group, out float vollume)
    {        
        mixer.GetFloat(group, out vollume);        
    }

    public static void SaveVolumeSettings(AudioMixer mixer)
    {
        //SaveVolume(mixer, "MasterVolume", out MasterVolume);
        //SaveVolume(mixer, "MusicVolume", out MusicVolume);
        //SaveVolume(mixer, "WeaponVolume", out WeaponVolume);

        mixer.GetFloat("MasterVolume", out MasterVolume);
        mixer.GetFloat("MusicVolume", out MusicVolume);
        mixer.GetFloat("WeaponVolume", out WeaponVolume);

        Debug.Log($"S Master {MasterVolume} Music {MusicVolume} Weapon {WeaponVolume}");
    }

    public static void LoadVolume(AudioMixer mixer, string group, float vollume)
    {
        mixer.SetFloat(group, vollume);
    }

    public static void LoadVolumeSettings(AudioMixer mixer)
    {
        Debug.Log($"L Master {MasterVolume} Music {MusicVolume} Weapon {WeaponVolume}");

        //LoadVolume(mixer, "MasterVolume", MasterVolume);
        //LoadVolume(mixer, "MusicVolume", MusicVolume);
        //LoadVolume(mixer, "WeaponVolume", WeaponVolume);

        mixer.SetFloat("MasterVolume", MasterVolume);
        mixer.SetFloat("MusicVolume", MusicVolume);
        mixer.SetFloat("WeaponVolume", WeaponVolume);
    }

    #endregion
}
