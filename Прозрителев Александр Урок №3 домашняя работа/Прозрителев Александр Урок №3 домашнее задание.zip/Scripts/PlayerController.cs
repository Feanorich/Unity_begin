﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class PlayerController : MonoBehaviour
{
    #region Fields

    public GameObject CurrentKey;   //Выбранный ключ
    [SerializeField] private Transform _keyPoint;   //точка, куда вешаем ключ
    [SerializeField] private GameObject _currentWearpon;   //Выбранное оружие
    [SerializeField] private Transform _rightHandPoint;   //точка, куда вешаем оружие        
    [SerializeField] private float _speed = 1f;   // Скорость движения
    [SerializeField] private float _rotationSpeed = 50f;   // Скорость вращения
    [SerializeField] private float _jump = 1f;   // Сила прыжка
    [SerializeField] private Vector3 _direction;   // Направление движения        
    private bool _checkWearpon = false;
    private float _rotation;

    #endregion

    public void GetItem(GameObject item)
    {
        if (item.CompareTag("Wearpon"))
        {
            item.transform.position = _rightHandPoint.transform.position;
            item.transform.rotation = _rightHandPoint.transform.rotation;
            item.transform.parent = _rightHandPoint;
            _currentWearpon = item;
            _checkWearpon = true;
        }
        else if (item.CompareTag("Key"))
        {
            item.transform.position = _keyPoint.transform.position;
            item.transform.rotation = _keyPoint.transform.rotation;
            item.transform.parent = _keyPoint;
            CurrentKey = item;
        }
    }

    #region UnityMethods

    // Start is called before the first frame update
    void Start()
    {
        
    }
    
    private void Update()
    {
        _rotation = Input.GetAxis("Horizontal");
        _direction.z = Input.GetAxis("Vertical");
        _direction.Normalize();

        _direction.y = Input.GetAxis("Jump") * _jump;    //нормализация до прыжка - это не баг а фича

        if (Input.GetButtonDown("Fire1"))
        {
            print("Gun fire");
            if (_checkWearpon == true) 
            {
                print(_currentWearpon);
                _currentWearpon.GetComponent<GunController>().Fire();                
            }
        }

    }

    private void FixedUpdate()
    {
        var speed = _direction * _speed * Time.deltaTime;
        transform.Translate(speed);

        transform.Rotate(Vector3.up * _rotation * _rotationSpeed * Time.deltaTime, Space.Self);

    }

    #endregion


}
