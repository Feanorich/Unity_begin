﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class TurretController : MonoBehaviour
{
    #region Fields

    [SerializeField] private Transform _target;       
    [SerializeField] private float _rotationSpeed = 50f;   // Скорость вращения
    [SerializeField] private float _range = 1f;
    private bool _aiming = false;
    #endregion

    // Start is called before the first frame update
    void Start()
    {
        if (_target != null)
        {
            _aiming = true;
        }
    }

    private void FixedUpdate()
    {
        if (_aiming == true)
        {            
            if ((transform.position - _target.position).sqrMagnitude < _range * _range)
            {
                //transform.rotation = Quaternion.LookRotation(_target.position);
                transform.LookAt(_target.position);
            }
        }
        else
        {
            Start();
        }
    }
}
