﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    #region Fields

    [SerializeField] private GameObject _player;

    #endregion


    #region UnityMethods

    void FixedUpdate()
    {
        transform.position = _player.transform.position;
        transform.rotation = _player.transform.rotation;
    }

    #endregion
}
