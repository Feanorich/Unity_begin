﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreatureSpawner : MonoBehaviour
{
    [SerializeField] private float _spawnTime; // время спавна
    [SerializeField] private GameObject _creature; //спавнящее существо 
    private float _count;

    private void SetTimer() //взведем таймер
    {
        _count = _spawnTime;
    }
    
    private void Start()
    {
        SetTimer();
    }

    
    private void Update()
    {
        if (_spawnTime > 0f) 
        {
            _count -= Time.deltaTime;
        }
        else // будем считать, что счетчик выключен
        {
            //знаю, что это пустая часть не нужна. тут был отладочный код
        }
        
    }

    private void FixedUpdate()
    {
        if (_count <= 0 )
        {
            Instantiate(_creature, transform.position, transform.rotation);

            SetTimer();
        }

    }
}
