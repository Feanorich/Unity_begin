﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class EnemyController : MonoBehaviour
{
    [SerializeField] private float _speed; // Скорость движения
    private Vector3 _direction; // Направление движения
    private float _directionMod = 1f; //модификатор направления 

    private void SetDir()
    {
        _direction.z = _directionMod;
    }
    // Start is called before the first frame update
    private void Start()
    {
        SetDir();
    }

    // Update is called once per frame
    private void Update()
    {
        SetDir();
    }

    private void FixedUpdate()
    {
        var speed = _direction * _speed * Time.deltaTime;
        transform.Translate(speed);

    }

    private void OnCollisionEnter(Collision other)
    {
        print(other.gameObject.name);
        if (other.gameObject.CompareTag("Wall"))
        {
            _directionMod = _directionMod * -1f;
            SetDir();
        }
        
    }
}
