﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LootController : MonoBehaviour
{
    #region Fields

    [SerializeField] private GameObject _loot; //Лутаемый предмет        
    [SerializeField] private float _rotationSpeed = 20f; // Скорость вращения    

    #endregion


    #region UnityMethods

    private void OnCollisionEnter(Collision other)
    {
        print(other.gameObject.name);
        if (other.gameObject.CompareTag("Player"))
        {
            var player = other.gameObject;
            player.GetComponent<PlayerController>().GetItem(_loot);
            Destroy(gameObject);
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    private void FixedUpdate()
    {
        transform.Rotate(Vector3.up * _rotationSpeed * Time.deltaTime, Space.Self);
    }

    #endregion 
}
