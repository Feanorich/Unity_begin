﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoorController : MonoBehaviour
{
    #region Fields

    [SerializeField] private GameObject _key;
    [SerializeField] private float _rotationSpeed = 1f; 
    private bool _rotate = false;
    private Quaternion _openDoor;
    private Quaternion _closedDoor;
    private float _rotation = 0f;


    #endregion

    private void OnCollisionEnter(Collision other)
    {
        print(other.gameObject.name);
        if (other.gameObject.CompareTag("Player"))
        {
            var player = other.gameObject;
            var currentKey = player.GetComponent<PlayerController>().CurrentKey;
            if ((_key == null) || (currentKey == _key))
            {
                _rotate = true;
                Destroy(_key);
            }
        }
    }

    // Start is called before the first frame update
    private void Start()
    {
        _openDoor = Quaternion.FromToRotation(Vector3.forward, Vector3.left);
        _closedDoor = transform.rotation;
    }

    // Update is called once per frame
    private void FixedUpdate()
    {
        if (_rotate == true)
        {
            _rotation += _rotationSpeed * Time.deltaTime;
            transform.rotation = Quaternion.Slerp(_closedDoor, _openDoor, _rotation);
        }
        
    }
}
