﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Laser : MonoBehaviour
{
    [SerializeField] private float _speed = 4; // Скорость движения
    [SerializeField] private float _lifetime = 4; // время жизни
    private Vector3 _direction; // Направление движения

    void Start()
    {
        _direction.z = 1;
        Destroy(gameObject, _lifetime);
    }
    
    void Update()
    {
        _direction.z = 1;
    }

    private void FixedUpdate()
    {
        var speed = _direction * _speed * Time.deltaTime;
        transform.Translate(speed);

    }

    private void OnTriggerEnter(Collider other)
    {
        print("111" + other.gameObject.name);
        if (other.gameObject.CompareTag("Enemy"))
        {
            Destroy(other.gameObject);
        }
        Destroy(gameObject);
    }
}
