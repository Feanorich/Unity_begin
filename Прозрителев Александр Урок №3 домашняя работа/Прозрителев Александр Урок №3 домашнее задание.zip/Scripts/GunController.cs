﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GunController : MonoBehaviour
{
    #region Fields
        
    [SerializeField] private GameObject _bullet; //пуля, которой стреляем
    [SerializeField] private Transform _firePoint; //точка, откуда вылетают пули    

    #endregion

    public void Fire()
    {
        print("bullet fire");
        Instantiate(_bullet, _firePoint.position, _firePoint.rotation);
    }        
    
}
